/**
 * @license Licensed under the Apache License, Version 2.0 (the "License"):
 *          http://www.apache.org/licenses/LICENSE-2.0
 */

/**
 * @fileoverview Generating Arduino code for the logic blocks.
 */
'use strict';

goog.provide('Blockly.Arduino.smorphi_variables');

goog.require('Blockly.Arduino');

Blockly.Arduino['right_sensor_status'] = function(block) {
  // TODO: Assemble Arduino into code variable.
  var code = 'right_sensor_status';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.Arduino.ORDER_NONE];
};
Blockly.Arduino['left_sensor_status'] = function(block) {
  // TODO: Assemble Arduino into code variable.
  var code = 'left_sensor_status';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.Arduino.ORDER_NONE];
};
Blockly.Arduino['front_sensor_status'] = function(block) {
  // TODO: Assemble Arduino into code variable.
  var code = 'front_sensor_status';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.Arduino.ORDER_NONE];
};
Blockly.Arduino['rear_sensor_status'] = function(block) {
  // TODO: Assemble Arduino into code variable.
  var code = 'rear_sensor_status';
  // TODO: Change ORDER_NONE to the correct strength.
  return [code, Blockly.Arduino.ORDER_NONE];
};
